
from typing import Literal
Scale = Literal[ 10, 20, 30, 40, 45, 50, 55, 60, 70]

# yay
